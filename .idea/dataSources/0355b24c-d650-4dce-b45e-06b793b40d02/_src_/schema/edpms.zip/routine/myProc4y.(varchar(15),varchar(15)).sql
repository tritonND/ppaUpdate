CREATE PROCEDURE myProc4y(IN val VARCHAR(15), IN val2 VARCHAR(15))
  BEGIN
    DROP TEMPORARY TABLE IF EXISTS ttab;
    create TEMPORARY TABLE IF NOT EXISTS ttab (SELECT projectdetails.PROJECTID, projectdetails.CONTRACTOR, projectdetails.CONTRACTSUM, projectdetails.DATEOFAWARD as dates,
    (SELECT SUM(AMOUNT) from certificates WHERE projectdetails.PROJECTID = certificates.PROJECTID  AND certificates.DATEISSUED BETWEEN val AND  val2 GROUP BY certificates.PROJECTID) as cAmount,
    (SELECT SUM(AMOUNT) from variations WHERE projectdetails.PROJECTID = variations.PROJECTID  AND variations.DATEISSUED BETWEEN val AND  val2 GROUP BY variations.PROJECTID ) as vAmount
    FROM projectdetails
    LEFT JOIN variations ON projectdetails.PROJECTID = variations.PROJECTID
    LEFT JOIN certificates ON projectdetails.PROJECTID = certificates.PROJECTID
    GROUP BY projectdetails.PROJECTID) ;
    (SELECT CONTRACTOR, SUM(CONTRACTSUM) as CSUM1, SUM(cAmount) as CAMOUNT, SUM(vAmount) as VAMOUNT from ttab WHERE dates BETWEEN val AND  val2 GROUP BY CONTRACTOR);

  END;
