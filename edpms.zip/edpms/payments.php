<!DOCTYPE html>
<?php
//session_start();
//if(isset($_SESSION['firstname']))
//{
//$username=$_SESSION['firstname'];
//}
//else{
//    header("Location: index.php");
//}
?>
<html lang="en">

  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>EDPMS | EDPMS</title>

    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="vendors/nprogress/nprogress.css" rel="stylesheet">
    
    <!-- Custom styling plus plugins -->
    <link href="build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
<!--          left side menu from top to bottom-->
<?php include './sidemenu.php'; ?>
        </div>

        <!-- top navigation -->
        <?php include './topnavigation.php'; ?>
        <!-- /top navigation -->
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            

            

            <div class="col-sm-12">
                <h2>content here</h2>
                <div class="col-sm-6">
                            <div class="form-group">
    <label for="number">Contract Sum Outstanding N:</label>
    <input type="number" class="form-control" id="subhead">
    </div> 
                            <div class="form-group">
    <label for="number">Certificates Issued N:</label>
    <input type="number" class="form-control" id="subhead">
    </div> 
                            <div class="form-group">
    <label for="number">Certificates Approved N:</label>
    <input type="number" class="form-control" id="subhead">
    </div> 
                            <div class="form-group">
    <label for="number">Certificates Awaiting Approval N:</label>
    <input type="number" class="form-control" id="subhead">
    </div> 
                            <div class="form-group">
    <label for="number">Payments to Date N:</label>
    <input type="number" class="form-control" id="subhead">
    </div> 
                            <div class="form-group">
    <label for="number">Payment Status:</label>
    <input type="number" class="form-control" id="subhead">
    </div> 
                            <div class="form-group">
    <label for="number">Approved Unpaid Certificates N:</label>
    <input type="number" class="form-control" id="subhead">
    </div> 
                            <div class="form-group">
    <label for="number">Unpaid Certified Works N:</label>
    <input type="number" class="form-control" id="subhead">
    </div> 
                            <div class="form-group">
    <label for="number">Value of Works Outstanding:</label>
    <input type="number" class="form-control" id="subhead">
    </div> 
                    </div>
                
            </div>
            
     </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
            Edo State Public Procurement Agency
          </div>
          <div class="clearfix">
              
</div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="vendors/nprogress/nprogress.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="build/js/custom.min.js"></script>
    <script src="js/searchtable.js"></script>
    <script src="js/autofilter.js"></script>

 <script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
});
</script>
  
  </body>
</html>